from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render, HttpResponse, redirect
from django.db.models import Q

# Create your views here.
from eccom.carrito import Carrito
from eccom.models import producto

# Create your views here.
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            usuario_logeado = User.objects.last()
            #username = form.cleaned_data['username']
            messages.success(request, f"El usuario ha sido registrado exitosamente!")
            return render(request,'index.html')
           
        else:
            messages.success(request, "No se pudo registrar el usuario, vuelva a intenarlo!")

    return render(request, 'registration/register.html')

def login(request):
    return render(request, 'registration/login.html');
def exit(request):
    logout(request)
    return redirect('/');
    
def index(request):
    
    articulos = producto.objects.all()
    paginator = Paginator(articulos, 12)  # Cambia 4 al número deseado de artículos por página
    page = request.GET.get('page')
    try:
        articulos = paginator.page(page)
    except PageNotAnInteger:
        articulos = paginator.page(1)
    except EmptyPage:
        articulos = paginator.page(paginator.num_pages)
    return render(request, 'index.html', {'articulos': articulos})

def todo(request):
    query = request.GET.get('q')
    categoria = request.GET.get('categoria')  # Obtener el valor de la categoría seleccionada, si lo hay
    
    # Filtrar los productos por nombre, categoría o plataforma si hay una consulta de búsqueda
    if query:
        articulos = producto.objects.filter(Q(nombre__icontains=query) | Q(categoria__icontains=query) | Q(platform__icontains=query))
    else:
        articulos = producto.objects.all()
    
    # Filtrar por categoría si se ha seleccionado una
    if categoria and categoria != '0':
        articulos = articulos.filter(categoria=categoria)  # Ajusta esto según tu modelo de Producto
        
    paginator = Paginator(articulos, 30)
    page = request.GET.get('page')
    try:
        articulos = paginator.page(page)
    except PageNotAnInteger:
        articulos = paginator.page(1)
    except EmptyPage:
        articulos = paginator.page(paginator.num_pages)
    
    return render(request, 'todos.html', {'articulos': articulos})

def detalle_articulo(request, producto_id):
    usuario = request.user
    carrito = Carrito(request)
    articulo = producto.objects.get(id=producto_id)
    return render(request, 'detalle_articulo.html', {'articulo': articulo, 'usuario': usuario})

def carrito(request):
    usuario = request.user
    return render(request,'carrito_index.html', {'usuario': usuario});

def agregar_producto(request, producto_id):
    carrito = Carrito(request)
    Producto = producto.objects.get(id=producto_id)
    carrito.agregar(Producto)
    return redirect("carrito")

def eliminar_producto(request, producto_id):
    carrito = Carrito(request)
    Producto = producto.objects.get(id=producto_id)
    carrito.eliminar(Producto)
    return redirect("carrito")

def restar_producto(request, producto_id):
    carrito = Carrito(request)
    Producto = producto.objects.get(id=producto_id)
    carrito.restar(Producto)
    return redirect("carrito")

def limpiar_carrito(request):
    carrito = Carrito(request)
    carrito.limpiar()
    return redirect("carrito")

