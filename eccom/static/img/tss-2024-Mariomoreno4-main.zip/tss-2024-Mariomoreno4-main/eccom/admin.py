from import_export import resources
from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .models import producto

# Register your models here.



class LibroResources(resources.ModelResource):
    
    fields={
        'nombre',
        'descripcion',
        'precio',
        'id'
    }
    class Meta:
        model=producto
        
        
        
@admin.register(producto)  
class productos(ImportExportModelAdmin):
    resource_class=LibroResources
    