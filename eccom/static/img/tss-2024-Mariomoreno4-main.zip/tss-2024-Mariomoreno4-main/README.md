<h2>Documentacion</h2>
https://docs.google.com/document/d/1ccgk5cKa3TMXGIh23OdfJRuNPvmyZ0GCmTlWn7shzYo/edit?usp=sharing
<h2>Grafica de gantt</h2>
https://sharing.clickup.com/9014120333/l/h/6-901401548941-1/2f6caf9a676cdf2
